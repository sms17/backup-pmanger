const mongoose = require('mongoose');
const Schema = mongoose.Schema;
 
// List of columns for Employee schema
let Event = new Schema({
 event_id: {
 type: String
 },
 event_name: {
 type: String
 }
},{
 collection: 'events'
});
 
module.exports = mongoose.model('Event', Event);