// Importing important packages
const express = require('express');

// Using express and routes
const app = express();
const eventRoute = express.Router();

// Event module which is required and imported
let eventModel = require('../models/Event');

// To Get List Of Events
eventRoute.route('/').get(function (req, res) {
eventModel.find(function (err, event) {
if (err) {
console.log(err);
}
else {
res.json(event);
}
});
});

// To Add New Event
eventRoute.route('/addEvent').post(function (req, res) {
let event = new eventModel(req.body);
event.save()
.then(game => {
res.status(200).json({ 'event': 'Event Added Successfully' });
})
.catch(err => {
res.status(400).send("Something Went Wrong");
});
});

// To Get Event Details By Event ID
eventRoute.route('/editEvent/:id').get(function (req, res) {
let id = req.params.id;
eventModel.findById(id, function (err, event) {
res.json(event);
});
});

// To Update The Event Details
eventRoute.route('/updateEvent/:id').post(function (req, res) {
eventModel.findById(req.params.id, function (err, event) {
if (!event)
return next(new Error('Unable To Find Event With This Id'));
else {
event.firstName = req.body.firstName;
event.lastName = req.body.lastName;
event.email = req.body.email;
event.phone = req.body.phone;

event.save().then(emp => {
res.json('Event Updated Successfully');
})
.catch(err => {
res.status(400).send("Unable To Update Event");
});
}
});
});

// To Delete The Event
eventRoute.route('/deleteEvent/:id').get(function (req, res) {
eventModel.findByIdAndRemove({ _id: req.params.id }, function (err, event) {
if (err) res.json(err);
else res.json('Event Deleted Successfully');
});
});

module.exports = eventRoute;