import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { catchError, tap, map } from 'rxjs/operators';
import { Event } from './event';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})

export class ApiService {

   // Main api url to call api
 uri = 'http://localhost:4000/events';
 
  constructor(private http: HttpClient) { }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
  
      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead
  
      // Let the app keep running by returning an empty result.
      return of(result as T);
    };
  }
// To Get The List Of Event
getEvents() {
  return this
  .http
  .get(`${this.uri}`);
  }
  
  // To Get Event Details For Single Record Using Id
  getEventById(empid) {
  return this.http.get(`${this.uri}/editEvent/${empid}`);
  }
  
  // To Updated Specific Event
  updateEvent(id, body) {
  return this.http.post(`${this.uri}/updateEvent/${id}`, body);
  }
  
  // To Create/Add New Event
  addEvent(body) {
  return this.http.post(`${this.uri}/addEvent`, body);
  }
  
  // To Delete Any Event
  deleteEvent(empid) {
  return this.http.get(`${this.uri}/deleteEvent/${empid}`);
  }
  
}
