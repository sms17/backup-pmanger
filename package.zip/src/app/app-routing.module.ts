import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EventComponent } from './event/event.component';
import { EventDetailComponent } from './event-detail/event-detail.component';
import { EventAddComponent } from './event-add/event-add.component';
import { EventEditComponent } from './event-edit/event-edit.component';

const routes: Routes = [
  {
    path: 'event',
    component: EventComponent,
    data: { title: 'List of event' }
  },
  {
    path: 'event-details/:id',
    component: EventDetailComponent,
    data: { title: 'event Details' }
  },
  {
    path: 'event-add',
    component: EventAddComponent,
    data: { title: 'Add event' }
  },
  {
    path: 'event-edit/:id',
    component: EventEditComponent,
    data: { title: 'Edit event' }
  },
  { path: '',
    redirectTo: '/event',
    pathMatch: 'full'
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
