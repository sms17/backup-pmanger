export class Event {
    id: number;
    event_id: string;
    event_name: string;
}