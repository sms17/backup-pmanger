import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { MatPaginator, MatSort, MatTableDataSource } from '@angular/material';

import { ApiService } from '../api.service';
//import { Event } from '../event';

export interface Event {
  event_id: string;
  event_name: string;
 }

@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {

  constructor(private api: ApiService, private router: Router) { }

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  
  // Important objects
  MyDataSource: any;
  eventList: Event[];
  displayedColumns: string[] = ['event_id', 'event_name','action'];
  

  
  ngOnInit() {
  this.getEvents();
  }
  
  // To Get List Of Employee
  getEvents() {
  this.api
  .getEvents()
  .subscribe((data: Event[]) => {
  this.MyDataSource = new MatTableDataSource();
  this.MyDataSource.data = data;
  this.MyDataSource.paginator = this.paginator;
  this.MyDataSource.sort = this.sort;
  });
  }
  
  // To Edit Employee
  editEmployee(empid) {
  this.router.navigate([`/Crud/edit/${empid}`]);
  }
  
  /**/
  // Search specific result
  filterEmployee(searchstring: string) {
  searchstring = searchstring.trim();
  searchstring = searchstring.toLowerCase();
  this.MyDataSource.filter = searchstring;
  }
}
